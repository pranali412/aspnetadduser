﻿namespace User.Domain.ViewModel
{
    public class DoctorDropdownVm
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
